# EchoSwap
This repository will contain all of required solidity contract, documents and tutorials.
Links: https://docs.google.com/document/d/14d-q6SXhFW1T9D3798wq9fx2crVqyIZuQdlOkcO_PsA/edit?usp=sharing

## Thena.fi
Links: https://github.com/ThenafiBNB/THENA-Contracts , https://docs.google.com/spreadsheets/d/1nk-OLHL6yZ3rvTYo2-OXTVpjgfo5PVyufmM1U4S8geA/edit#gid=0


<ol>
  <li>npm install</li>
  <li>npx hardhat compile</li>
</ol>
