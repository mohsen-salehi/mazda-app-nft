const { ethers } = require("hardhat");

async function main() {
    const EchoHolders = await ethers.getContractFactory("EchoHolders");
    const contractAddress = "0x6D5d6CE9Bc3F30aB84073Ef943e6681808c8a56D"; // Replace with the deployed contract address
    const contract = EchoHolders.attach(contractAddress);
    console.log(
        `contract data:\n`,
        `MAX_SUPPLY : ${(await contract.MAX_SUPPLY()).toString()} \n`,
        `NFT_PRICE : ${(await contract.NFT_PRICE()).toString()} \n`,
        `MAX_PER_MINT : ${(await contract.MAX_PER_MINT()).toString()} \n`,
        `MAX_RESERVE : ${(await contract.MAX_RESERVE()).toString()} \n`,
        `reservedAmount : ${(await contract.reservedAmount()).toString()} \n`,
        `root : ${(await contract.root()).toString()} \n`,
        `presale : ${(await contract.presale()).toString()} \n`,
        `baseURI : ${(await contract.baseURI()).toString()} \n`,
        `name : ${(await contract.name()).toString()} \n`,
        `owner : ${(await contract.owner()).toString()} \n`,
        `symbol : ${(await contract.symbol()).toString()} \n`,
        `totalSupply : ${(await contract.totalSupply()).toString()}`
    );
}

// Run the deployment function
main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
