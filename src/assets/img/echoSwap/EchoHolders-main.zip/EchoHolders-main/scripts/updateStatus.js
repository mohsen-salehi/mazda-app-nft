const { ethers } = require("hardhat");

async function main() {
    // Change this with the actual parameters you want to update
    const newNFTPrice = 100; // for example, 100 wei
    const newMaxPerMint = 5; // for example, allow up to 5 tokens per mint
    // enum Status {PublicSale,PrivateSale,WhiteListSale,Stop}   
    const newStatus = 3; // 1 could represent the status "Open," for example

    // Get the contract artifacts (replace 'YourContract' with your actual contract name)
    const EchoHolders = await ethers.getContractFactory("EchoHolders");
    const contractAddress = "0x6D5d6CE9Bc3F30aB84073Ef943e6681808c8a56D"; // Replace with the deployed contract address

    // Connect to the deployed contract using its address
    const contract = EchoHolders.attach(contractAddress);

    // Call the updateStatus function using the 'connect' instance
    await contract.updateStatus(newNFTPrice, newMaxPerMint, newStatus);

    console.log(
        "Status updated successfully!",
        (await contract.presale()).toString(),
        (await contract.MAX_PER_MINT()).toString(),
        (await contract.NFT_PRICE()).toString()
    );
}

// Run the deployment function
main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
