const http = require('http');
const url = require('url');

http.createServer((req, res) => {
    // Get the id parameter from the URL
    let id = parseInt(url.parse(req.url, true).query.id) || 0;
    // Define the metadata properties
    const name = `Echoswap NFT #${id}`;
    const description = `EchoNFT represent astronaut's thoughts by captures this sense of wonder and exploration, with 1500 randomly generated stars, meteors, and planets that are each unique and full of creative imagination`;
    const image = `https://wechart.io/oss/EchoSwap/All%20NFT%20image/${id + 1 }.png`;
    const external_url = "https://echoswap.xyz";

    // Create the metadata object
    const metadata = {
    name: name,
    description: description,
    image: image,
    external_url: external_url
    };

    // Set the content type header to JSON
    res.setHeader('Content-Type', 'application/json');

    // Output the metadata as JSON
    res.end(JSON.stringify(metadata, null, 2));
}).listen(8080, () => {
  console.log('Server listening on port 8080');
});
