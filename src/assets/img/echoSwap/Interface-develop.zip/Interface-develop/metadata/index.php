<?php

// Get the id parameter from the URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Define the metadata properties
$name = "Echoswap NFT #" . $id;
$description = "EchoNFT represent astronaut's thoughts by captures this sense of wonder and exploration, with 1500 randomly generated stars, meteors, and planets that are each unique and full of creative imagination";
$image = "https://wechart.io/oss/EchoSwap/All%20NFT%20image/" . $id + 1 . ".png";
$external_url= "https://echoswap.xyz";

// Create the metadata array
$metadata = [
    "name" => $name,
    "description" => $description,
    "image" => $image,
    "external_url" => $external_url
];

// Set the content type header to JSON
header('Content-Type: application/json');

// Output the metadata as JSON
echo json_encode($metadata, JSON_PRETTY_PRINT);

?>