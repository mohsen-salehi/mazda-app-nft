import Image from 'next/image';
import logo from './../../public/logo.png';
import { useState, useEffect } from 'react';
export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    // Clean up event listener on unmount
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  return (
    <div
      className={`text-white  h-[60px] flex justify-between p-4 w-full fixed top-0 left-0 bg-black bg-opacity-70 backdrop-blur-3xl ${
        scrolled ? 'border-b' : ''
      }`}
    >
      <Image src={logo} alt={'logo'} width={143} height={30} />
      <button className="p-2 font-semibold border justify-center items-center text-brand border-brand px-4 hidden md:flex md:justify-center md:items-center">
        Launch App
      </button>
    </div>
  );
}
