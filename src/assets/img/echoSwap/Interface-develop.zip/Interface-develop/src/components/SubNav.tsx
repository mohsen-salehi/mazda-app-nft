import { bottomIcons } from '../routes/sidebar'
import Link from 'next/link'
import {
  TbChevronRight
} from 'react-icons/tb'
export function SubNav() {
  return (
    <>
      <section className=" w-full lg:pl-12">
        <div className="text-2xl px-4 font-semibold lg:pt-12 lg:pl-32  text-white lg:w-[748px] lg:text-5xl">
          <h1 className="leading-1 text-5xl" style={{lineHeight:"4rem"}}>
            THE NATIVE LIQUIDITY LAYER ON
            <span className="text-brand"> zkSync</span>
          </h1>
        </div>
        <p className="text-gray-400 text-sm mt-3 px-4 mb-5 lg:px-0 lg:text-lg lg:w-[623px] lg:pl-32">
          EchoSwap was designed to onboard the native liquidity AMM protocols to
          the zkSync against opening up a free market for $ECHO emissions.
        </p>
        <div className="flex flex-col gap-4 pt-6 px-3 lg:p-0 lg:pl-32 lg:flex-row lg:items-center lg:gap-8">
          <div className="flex gap-3">
          <button className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2 text-white p-2 px-4">
            <span className='text-right text-white text-sm font-medium uppercase leading-none'>Launch App</span>
            <span>
              <TbChevronRight style={{ width: '20px', height: '20px' }} />
            </span>
          </button>
            
            <Link className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2 text-white p-2 px-4"
            href='/Presale' key='presale'>
              <span className='text-right text-white text-sm font-medium uppercase leading-none'>mint NFT</span>
              <span>
                <TbChevronRight style={{ width: '20px', height: '20px' }} />
              </span>
            </Link>
          </div>
          <div className="flex items-center gap-4 ">
              {bottomIcons.map((item) => (
                <Link href={item.href} key={item.name} target="_blank">
                  
                    <item.icon
                      className="mx-2 h-10 w-10 flex-shrink-0 text-gray-400  hover:text-gray-200"
                      aria-hidden="true"
                    />
                  
                </Link>
              ))}
            
          </div>
        </div>
      </section>
    </>
  );
}
