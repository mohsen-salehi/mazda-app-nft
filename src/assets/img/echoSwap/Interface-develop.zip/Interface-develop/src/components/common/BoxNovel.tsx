import Image, { StaticImageData } from 'next/image';

interface Props {
  title: string;
  description: string;
  image: StaticImageData;
}
export default function BoxNovel({ title, description, image }: Props) {
  return (
    <div className="flex flex-col w-full border border-opacity-60 text-white">
      <div className="w-full flex justify content items-center gap-2.5 border-b p-5 border-opacity-60">
        <Image src={image} alt={`${image}`} width={34.17} height={39.42} />
        <h3>{title}</h3>
      </div>
      <div className="p-6 text-gray-400 text-sm">{description}</div>
    </div>
  );
}
