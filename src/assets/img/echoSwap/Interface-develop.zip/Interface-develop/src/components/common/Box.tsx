import {
  TbChevronRight
} from 'react-icons/tb'
interface Props {
  title: string;
  subTitle?: string;
  button?: string;
  desktopDescription?: string;
}
export default function Box({
  title,
  subTitle,
  button,
  desktopDescription,
}: Props) {
  return (
    
<div className="flex flex-col p-3 px-6 pb-5 h-full">
  <div className="flex flex-col flex-grow">
    <h2 className="font-bold text-white pt-10 text-lg">{title}</h2>
    <h3 className="font-medium text-white text-md pt-3">{subTitle}</h3>
    <p className="text-gray-400 pt-1 pb-4 text-md flex-grow">{desktopDescription}</p>
  </div>
  {button && (
    <div className="mt-auto">
      <button className="text-gray-400 hover:text-gray-200 flex items-center">
        <span className="text-right text-sm leading-none">{button}</span>
        <span>
          <TbChevronRight style={{ width: '16px', height: '16px' }} />
        </span>
      </button>
    </div>
  )}
</div>

  );
}
