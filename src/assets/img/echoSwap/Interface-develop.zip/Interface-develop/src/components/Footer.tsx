import Link from 'next/link'
export default function Footer() {
  return (
    <div className="w-full mt-8 text-white text-center">
      Incubated by 
      <Link href='https://twitter.com/WEconomyNetwork' key='twitter' 
      target="_blank"
      className='px-2 text-gray-400 hover:text-gray-200'>
        @WEconomy
      </Link>
    </div>
  );
}
