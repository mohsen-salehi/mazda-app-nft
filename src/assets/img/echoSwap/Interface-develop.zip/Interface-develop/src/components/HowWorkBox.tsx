interface Props {
  number: number;
  title: string;
  subTitle: string;
  description: string;
}
export default function HowWorkBox({
  number,
  title,
  subTitle,
  description,
}: Props) {
  return (
    <div className="p-10 text-white  lg:w-1/3">
      <div className="bg-brand text-white w-8 h-8 px-3 flex justify-content items-center mb-2 text-center text-xl font-bold">
        
        {number}
      </div>
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-xl font-medium mb-2">{subTitle}</p>
      <p className="text-sm  text-gray-400">{description}</p>
    </div>
  );
}
