import Image from 'next/image';
import roadMap from './../../public/roadmap.svg';
import taqvim from './../../public/taqvim.png';

export default function RoadMap() {
  return (
    <div className="w-full text-white flex flex-col border border-opacity-60">
      <div className="w-full p-5 text-2xl border-b border-opacity-60">Roadmap 2023</div>
      <div className="flex gap-5 px-5 lg:px-0 py-24 lg:items-center lg:justify-center">
        <Image
          src={roadMap}
          alt={`${roadMap}`}
          height={22}
          width={11}
          className=" lg:order-2"
        />
        <div className="flex flex-col gap-16 lg:gap-20  p-6 order-1">
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block lg:w-8"
            />
            <div>
              <h2 className="text-xl font-bold">July 2023</h2>
              <p className="text-sm">Community initiating, Airdrop campaign</p>
            </div>
          </div>
          <div className="flex gap-5 ">
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">August 2023</h2>
              <p className="text-sm">Presale NFTs minting</p>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block lg:w-8"
            />

            <div>
              <h2 className="text-xl font-bold">September 2023</h2>
              <p className="text-sm">Launch on zkSync mainnet</p>
            </div>
          </div>
          <div className="flex gap-5 ">
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">October 2023</h2>
              <p className="text-sm">Integration of Launchpad</p>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block lg:w-8"
            />

            <div>
              <h2 className="text-xl font-bold">November 2023</h2>
              <p className="text-sm">Liquidity growth strategy</p>
            </div>
          </div>
          <div className="flex gap-5">
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">December 2023</h2>
              <p className="text-sm"> 100,000,000 trading volume</p>
            </div>
          </div>
        </div>
        <div className=" hidden lg:flex lg:flex-col lg:order-3 lg:gap-20 lg:p-6">
          <div className="flex gap-5 ">
            <div></div>
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">July 2023</h2>
              <p className="text-sm">Community initiating, Airdrop campaign</p>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block w-8"
            />

            <div>
              <h2 className="text-xl font-bold">August 2023</h2>
              <p className="text-sm">Presale NFTs minting</p>
            </div>
          </div>
          <div className="flex gap-5">
            <div></div>
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">September 2023</h2>
              <p className="text-sm">Launch on zkSync mainnet</p>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block lg:w-8"
            />

            <div>
              <h2 className="text-xl font-bold">October 2023</h2>
              <p className="text-sm">Integration of Launchpad</p>
            </div>
          </div>
          <div className="flex gap-5">
            <div></div>
            <div className="lg:hidden">
              <h2 className="text-xl font-bold">November 2023</h2>
              <p className="text-sm">Liquidity growth strategy</p>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <Image
              src={taqvim}
              alt={`${taqvim}`}
              className="hidden lg:block lg:w-8"
            />

            <div>
              <h2 className="text-xl font-bold">December 2023</h2>
              <p className="text-sm"> 100,000,000 trading volume</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
