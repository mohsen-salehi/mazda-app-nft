import HowWorkBox from './HowWorkBox';

export default function HowWork() {
  return (
    <div className="border-t border-l border-r w-full text-white mt-16 flex flex-col border-opacity-60">
      <div className=" w-full p-5 font-bold text-2xl lg:text-center">
        How It Works
      </div>
      <div className="border-t w-full p-5 border-opacity-60">
        <h3 className="pb-2 font-semibold text-xl">veECHO Holders</h3>
        <p className="text-sm text-gray-300">
          Control Echoswap’s destiny by locking into veECHO.
        </p>
      </div>
      <div className="flex flex-col border-t border-b w-full md:flex-row border-opacity-60">
        <HowWorkBox
          number={1}
          title={'Lock ECHO'}
          subTitle={'Token and Receive veECHO'}
          description={
            'Lock ECHO for up to 2 years to receive vote-escrowed ECHO (veECHO). The longer the lock, the more veECHO you receive.'
          }
        />
        <div className='border-t lg:border-r border-opacity-60'></div>
          <HowWorkBox
            number={2}
            title={'Use veECHO to Vote'}
            subTitle={'for Your Favorite Pools'}
            description={
              'veECHO gives you the power to decide which pools should receive ECHO emissions.'
            }
          />
        <div className='border-t lg:border-r border-opacity-60'></div>
        <HowWorkBox
          number={3}
          title={'Receive Bribes'}
          subTitle={'and Trading Fees'}
          description={
            'Voting for a pool lets you claim a share of the weekly bribes and trading fees.'
          }
        />
      </div>
      <div className="p-5">
        <h3 className="pb-2 font-semibold text-xl">Protocols</h3>
        <p className="text-sm text-gray-300">
          Attract Echoswap’s emissions by locking into veECHO
        </p>
      </div>
      <div className="flex flex-col border-t border-b border-opacity-60 w-full md:flex-row ">
        <HowWorkBox
          number={4}
          title={'Request Gauge'}
          subTitle={'Whitelisting'}
          description={
            'Protocols that seek to open a gauge to be voted on have to request a whitelisting by presenting a proposal.'
          }
        />
        <div className='border-t lg:border-r border-opacity-60'></div>
        <HowWorkBox
          number={5}
          title={'Create a Bribe With'}
          subTitle={'Few Clicks'}
          description={
            'Once the gauge has been initiated, anyone can bribe it with just a few clicks. Bribes are set per epoch, which lasts for 7 days.'
          }
        />
        <div className='border-t lg:border-r border-opacity-60'></div>
        <HowWorkBox
          number={6}
          title={'Receive Emissions'}
          subTitle={'From veECHO Holders Votes'}
          description={
            'The emissions are distributed to the gauges for the new epoch based on votes from veECHO holders.'
          }
        />
      </div>
    </div>
  );
}
