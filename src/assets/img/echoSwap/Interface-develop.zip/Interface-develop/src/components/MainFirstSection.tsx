import Box from './common/Box';

export default function MainFirstSection() {
  return (
    <div className="w-full flex flex-col lg:grid lg:grid-rows-2 lg:grid-flow-col  md:flex-row md:justify-center ">
      <div className='lg:row-span-2 border lg:border-l lg:border-t lg:border-b border-opacity-60'>
        <Box
          title={'THE EchoSwap'}
          desktopDescription={`The first community-owned concentrated liquidity marketplace driving ve(3,3) concept on zkSync. 
          
          It drives the solidly concept of redistributing fees and token emissions to multiple roles with the features of staking, bribing and vote-escrowed tokens etc, involving community into the protocol to expand DeFi mission.`}
        />
      </div>
      
      
        <div className="flex flex-col lg:grid lg:grid-cols-2 lg:col-span-2 lg:border-t  border-l border-opacity-60 md:flex-row">
          <div className='lg:border-r border-r border-b border-opacity-60'>
            <Box
              title={'Swap Your Tokens'}
              subTitle={'With Low Slippage'}
              
              desktopDescription={
                'EchoSwap’s smart routing, deep liquidity, and latest AMM technology allow you to enjoy low slippage and high return when swapping one cryptocurrency for another.'
              }
              button={`Swap Now`}
            />
          </div>
          <div className=' lg:border-r border-r border-b border-opacity-60'>
            <Box
              title={'Stake and Earn'}
              subTitle={'Passive Income'}
              
              desktopDescription={
                'Stake your assets for instant passive income streams. No deposit or withdrawal fees. You have full control over your funds.'
              }
              button={`Start Staking`}
            />
          </div>
          
        </div>
        <div className="flex flex-col lg:grid lg:grid-cols-2 lg:col-span-2  border-l border-opacity-60 md:flex-row">
        <div className='lg:border-r border-r border-b border-opacity-60'>
          <Box
            title={'Stake liquidity to'}
            subTitle={'Earn ECHO emissions'}
            
            desktopDescription={
              'The deeper the liquidity (TVL), the lower the slippage a pool will offer. LPs get ECHO emissions and veECHO get the pool trading fees as incentive to vote on the most productive pools.'
            }
            button={'Deposit Liquidity'}
          />
          </div>
          <div className='lg:border-r border-r border-b border-opacity-60'>
          <Box
            title={'Cast your votes to'}
            subTitle={'Earn Bribes and Rewards'}
            
            desktopDescription={
              'veTHE holders participate in voting, receive bribes and rewards, and redirect emissions to the pool of LPs, thereby providing a flexible and capital-efficient solution to channel and expand liquidity.'
            }
            button={'Cast your vote'}
          />
          </div>
        </div>
    </div>
  );
}
