import React from 'react';
import { TbSquareX } from 'react-icons/tb';
import Image from 'next/image';
import success from '../../../Images/Success.svg';
import successCenter from '../../../Images/SuccessCenter.svg';
import TxError from '../../../Images/TxError.svg'

type TransactionModalProps = {
  isOpen: boolean;
  isLoading: boolean;
  isSuccess: boolean;
  onClose: () => void;
  transactionHash: string;
  errorMessage: string;
};

const TransactionModal: React.FC<TransactionModalProps> = ({ isOpen, isLoading, isSuccess, onClose, transactionHash, errorMessage }) => {
  const errorReason = 'The contract function "buy" reverted with the following reason:';
  const reasonStartIndex = errorMessage?.indexOf(errorReason);
  const contractCallStartIndex = errorMessage?.indexOf('Contract Call:');
  const lastindex = errorMessage?.indexOf('Request Arguments')
  let formattedErrorMessage = ''
  if (reasonStartIndex === -1){
    formattedErrorMessage = errorMessage?.substring( lastindex, contractCallStartIndex);
  } else {
     formattedErrorMessage = errorMessage?.substring(reasonStartIndex + errorReason.length, contractCallStartIndex);
  }

  console.log(errorMessage, reasonStartIndex)
  return (
    <div className={`fixed inset-0 z-50 ${isOpen ? '' : 'hidden'}`}>
      <div className="fixed inset-0 z-50 flex justify-center items-center h-screen bg-white bg-opacity-60">
        <div className="flex flex-col bg-neutral-800 rounded-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="text-gray-200 text-base font-bold capitalize">Mint EchoNFT</div>
            <button className="w-6 h-6 text-gray-300 hover:text-gray-200" onClick={onClose}>
              <TbSquareX />
            </button>
          </div>
          <div className="flex justify-center items-center pt-7">
            {!isLoading ? (isSuccess ? <Image src={successCenter} alt="success" />
             : <Image src={TxError} alt="success" />) : <Image src={success} alt="success" className="animate-spin" />}

          </div>
          {!isLoading ? (isSuccess ? (
            <div className="pt-10 space-y-4 text-center">
              <div className="text-gray-200 text-base font-bold leading-tight">NFT Minted Successfully</div>
              <p className="text-gray-300 text-sm leading-tight">Transaction has been confirmed by the blockchain.</p>
              <button className="mt-7 w-full px-4 py-2 bg-blue-600 text-white text-base font-bold rounded-sm" onClick={onClose}>
                Close
              </button>
              <div className="w-full mt-4 text-center">
                <a
                  href={`https://opbnb-testnet.bscscan.com/tx/${transactionHash}`}
                  className="text-blue-600 text-xs font-normal hover:underline"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View on Block Explorer
                </a>
              </div>
            </div>
          ) : (
            <div className="pt-10 text-center">
              <div className='items-center px-12 pb-4'>
                <h2 className="text-2xl font-bold mb-4">Transaction Failed</h2>
                <p className="text-gray-300 text-sm leading-tight">{formattedErrorMessage || 'There was an error processing your transaction.'}</p>
              </div>
              <button className="w-full mt-7 px-4 py-2 bg-blue-600 text-white text-base font-bold rounded-sm" onClick={onClose}>
                Close
              </button>
            </div>
          )) : (
            <div className="pt-10 text-center">
              <div className='items-center px-12 pb-4'>
                <h2 className="text-2xl font-bold mb-4">Please check your wallet <br /> to submit the transaction.</h2>
              </div>
            </div>
          )
          }
          
        </div>

      </div>
    </div>
  );
};

export default TransactionModal;
