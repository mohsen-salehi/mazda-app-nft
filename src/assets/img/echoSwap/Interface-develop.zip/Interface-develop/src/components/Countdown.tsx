import React, { useState, useEffect } from 'react';
type CountdownTimerProps = {
  onDeadlinePass: (hasPassed: boolean) => void;
};
const CountdownTimer: React.FC<CountdownTimerProps> = ({ onDeadlinePass }) => {
  const [days, setDays] = useState(30);
  const [hours, setHours] = useState(5);
  const [minutes, setMinutes] = useState(28);
  const [seconds, setSeconds] = useState(48);

  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds((prevSeconds) => prevSeconds - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);
  const isDeadlinePassed = () => {
    return days === 0 && hours === 0 && minutes === 0 && seconds <= 0;
  };
  useEffect(() => {
    if (isDeadlinePassed()) {
      onDeadlinePass(true)
      setSeconds(0);
      return;
    }
  
    if (seconds < 0) {
      setSeconds(59);
      setMinutes((prevMinutes) => prevMinutes - 1);
    }
    if (minutes < 0) {
      setMinutes(59);
      setHours((prevHours) => prevHours - 1);
    }
    if (hours < 0) {
      setHours(23);
      setDays((prevDays) => prevDays - 1);
    }
  }, [seconds, minutes, hours]);

  return (
    <div className="flex items-center justify-start">
      <div className="w-20 h-20 bg-white rounded-xl flex flex-col items-center justify-center p-2 mr-3">
        <div className="text-black text-3xl font-bold leading-normal">{days}</div>
        <div className="text-zinc-700 text-sm font-bold lowercase leading-normal">day{days !== 1 && 's'}</div>
      </div>
      <div className="w-20 h-20 bg-white rounded-xl flex flex-col items-center justify-center p-2 mr-3">
        <div className="text-black text-3xl font-bold leading-normal">{hours}</div>
        <div className="text-zinc-700 text-sm font-bold lowercase leading-normal">hr{hours !== 1 && 's'}</div>
      </div>
      <div className="w-20 h-20 bg-white rounded-xl flex flex-col items-center justify-center p-2 mr-3">
        <div className="text-black text-3xl font-bold leading-normal">{minutes}</div>
        <div className="text-zinc-700 text-sm font-bold lowercase leading-normal">min{minutes !== 1 && 's'}</div>
      </div>
      <div className="w-20 h-20 bg-white rounded-xl flex flex-col items-center justify-center p-2 mr-3">
        <div className="text-black text-3xl font-bold leading-normal">{seconds}</div>
        <div className="text-zinc-700 text-sm font-bold lowercase leading-normal">sec{seconds !== 1 && 's'}</div>
      </div>
    </div>
  );
};

export default CountdownTimer;
