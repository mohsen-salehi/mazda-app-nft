import { Nav } from '@/components/Nav';
import { SubNav } from '@/components/SubNav';
import Head from 'next/head'
import Image from 'next/image';
import checkerd from '../../public/checkerd.svg';
import keyRectangle from '../../public/keyRectangle.svg';
import MainFirstSection from '@/components/MainFirstSection';
import HowWork from '@/components/HowWork';
import BoxNovel from '@/components/common/BoxNovel';
import NftSection from '@/components/NftSection';
import RoadMap from '@/components/RoadMap';
import novel4 from './../../public/novel4.svg';
import novel3 from './../../public/novel3.svg';
import novel2 from './../../public/novel2.svg';
import novel1 from './../../public/novel1.svg';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <>
      <header className="w-full fixed top-0 left-0 bg-black">
        <Head>
          <title>EchoSwap</title> 
          <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png"/>
          <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"/>
          <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png"/>
          <link rel="manifest" href="/site.webmanifest"/>
        </Head>
        <Nav />
      </header>
      <section className="w-full pt-24 lg:pt-28 lg:flex lg:pr-36 lg:items-center">
        <SubNav />
        <Image
          src={keyRectangle}
          alt="keyRectangle"
          width={250}
          height={120}
          className="hidden lg:block lg:pt-20"
        />
      </section>
      <Image src={checkerd} alt="checkerd" width={2210} height={253} />

      <main className="w-full  pb-8 ">
        
        <div className="px-10 mt-24 md:px-48 ">
          <MainFirstSection />
        </div>
        <div className="px-10 mt-40  md:mt-40 md:px-48">
          <HowWork />
        </div>
        <div className="px-10 mt-40  md:mt-40 md:px-48 flex flex-col gap-16">
          <BoxNovel
            title={'Novel ve(3,3) Tokenomics'}
            description={
              "The protocol incorporates the ve(3,3) Mechanics concept, combining the anti-dilution method from Olympus DAO with Curve's vote-escrowed model. This mechanism aims to protect veECHO holders from dilution and allows for a dynamic distribution of veECHO tokens among participants. The maximum anti-dilution level is set at 30%. ve(3,3) has proven to align the incentives of token holders and liquidity providers which has resulted in, among other things, market outperformance of projects."
            }
            image={novel1}
          />
          <BoxNovel
            title={'Community-Owned Protocol'}
            description={
              'EchoSwap owned native liquidity marketplace driving ve(3,3) concept on zkSync. It drives the solidly concept of redistributing fees and token emissions to multiple roles with the features of staking, bribing and vote-escrowed tokens etc, involving community into the protocol to expand DeFi mission.'
            }
            image={novel2}
          />
          <BoxNovel
            title={'Low Fee Hybrid vAMM/ sAMM'}
            description={
              'With fees ranging from 0.02% for stable pools to 0.1% for variable pools, EchoSwap allows traders to execute trades with minimal slippage. Executing a trade will follow the cheapest route based on available liquidity in the pools, with trading fees incurred.'
            }
            image={novel3}
          />
          <BoxNovel
            title={'Earn zkSync Airdrop'}
            description={
              'As everyone knows that the big airdrop season from Arbitrum and major protocols may receive incentives or airdrops during the TGE, but ZkSync is an even bigger project than Arbitrum. So we are dedicated to helping our users to earn the big opporunity of receiving airdrop from ZkSync era.'
            }
            image={novel4}
          />
        </div>
        <div className="px-10 mt-40  md:px-48">
          <NftSection />
        </div>
        <div className="px-10 mt-40 md:px-48">
          <RoadMap />
        </div>
        <Footer />
      </main>
    </>
  );
}
