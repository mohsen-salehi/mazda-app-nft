import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Head from 'next/head';
import copy from 'clipboard-copy';
import CountdownTimer from '../components/Countdown';
import { bottomIcons } from '../routes/sidebar';
import Image from 'next/image';
import PrivateSaleNFT from '../../Images/Private_sale_Cover.png';
import PublicSaleNFT from '../../Images/Public_sale_Cover.png';
import WhiteListSaleNFT from '../../Images/WhiteList_Sale_Cover.png';
import NavApp from '@/components/NavApp';
import { TbCopy } from 'react-icons/tb';
import { ConnectButtonMint } from '@/connectButton/ConnectButtonMint';
import {
    useNFTPrice,
    useBalanceOf,
    useMAXSupply,
    useMAXPerMint,
    usetotalSupply,
    useMAX_RESERVE,
    usePublicSaleBalance,
    usePrivateSaleeBalance,
    useWhiteListSaleBalance,
    usePresale
} from '../contracts/readState'
import { useAccount, useBalance } from 'wagmi'
import { getNetwork, watchNetwork, watchAccount } from '@wagmi/core'
import { formatEther, parseEther } from 'viem'
import { Buy } from '../contracts/WriteContract';
import { ELIGIBLE_ADDRESS } from '@/contracts/eligibleAddress';
import { CONTRACT_ADDRESS_TESTNET, CONTRACT_ADDRESS_MAINNET } from '@/contracts/addresses'
import TransactionModal from '../components/TransactionModal/TransactionModal';

const Presal = () => {
    const [inputValue, setInputValue] = useState(0);
    const [copied, setCopied] = useState(false);
    const [deadlinePassed, setDeadlinePassed] = useState(false);
    const [price, setPrice] = useState('0')
    const [balance, setBalance] = useState(0)
    const [AccountBlance, setAcountBalance] = useState(0)
    const [MaxPerMINT, setMaxPerMint] = useState(0)
    const [TotalSupply, settotalSupply] = useState(0)
    const [presale, setPresale] = useState(0)
    const [MaxSupply, setMAXSupply] = useState(0)
    const [account, setAccount] = useState('0')
    const [showModal, setShowModal] = useState(false);
    const [network, setNetwork] = useState(0);
    const [modalData, setModalData] = useState({
        isLoading: false,
        isSuccess: false,
        transactionHash: '',
        errorMessage: ''
    });
    const { address, isConnecting, isDisconnected, isConnected } = useAccount();
    const { data, isError } = useBalance({ address, watch: true, })
    const { data: nftPriceData } = useNFTPrice();
    const { data: maxSupplyData } = useMAXSupply();
    const { data: maxPerMintData } = useMAXPerMint();
    const { data: totalSupplyData } = usetotalSupply();
    const { data: maxReserveData } = useMAX_RESERVE();
    const { data: presaleData } = usePresale();
    const { data: balanceData } = useBalanceOf(account);
    const { data: WLSbalanceData } = useWhiteListSaleBalance(account);
    const { data: PrSbalanceData } = usePrivateSaleeBalance(account);
    const { data: PSbalanceData } = usePublicSaleBalance(account);
    const { data: txData, isLoading, isSuccess, error: TxError, handleBuy } = Buy();
    useEffect(() => {
        const { chain } = getNetwork();
        setNetwork(chain?.id || 0);

        const unwatch = watchNetwork(() => {
            const { chain } = getNetwork();
            setNetwork(chain?.id || 0);
        });
        const unwatchAccount = watchAccount(() =>
            readData()

        )
        console.log('account or chain changed')
        return () => {
            unwatch();
            unwatchAccount()
        };
    }, [address, network]);
    useEffect(() => {
        if (isConnected) {
            readData()
            console.log('wallet connected')
        } else if (isDisconnected) {
            resetState();
        }
    }, [isConnected, balance, address, data, txData, isDisconnected, nftPriceData, balanceData, WLSbalanceData,
        PrSbalanceData, PSbalanceData, presaleData, AccountBlance, maxPerMintData, totalSupplyData, maxSupplyData,
    ]);

    useEffect(() => {
        setModalData({
            isLoading: isLoading,
            isSuccess: isSuccess,
            transactionHash: txData?.hash ?? '',
            errorMessage: TxError?.cause ? TxError.message : ''
        });
        console.log()
    }, [isLoading, isSuccess, TxError, txData]);

    const readData = () => {
        setAcountBalance(Number(data?.formatted))
        setAccount(address as string);
        setPrice(formatEther(nftPriceData as bigint));
        setPresale(Number(presaleData) || 0);
        setMaxPerMint(Number(maxPerMintData) || 0);
        settotalSupply(Number(totalSupplyData) || 0);
        setMAXSupply(Number(maxSupplyData) || 0);
        if (Number(presaleData) === 0) {
            setBalance(Number(PSbalanceData) || 0);
        } else if (Number(presaleData) === 1) {
            setBalance((Number(PrSbalanceData)) || 0);
        } else if (Number(presaleData) === 2) {
            setBalance((Number(WLSbalanceData)) || 0);
        } else {
            setBalance((Number(balanceData)) || 0);
        }
    };
    const resetState = () => {
        setInputValue(0);
        setCopied(false);
        setDeadlinePassed(false);
        setPrice('0');
        setBalance(0);
        setMaxPerMint(0);
        settotalSupply(0);
        setPresale(0);
        setMAXSupply(0);
        setShowModal(false);
        setModalData({
            isLoading: false,
            isSuccess: false,
            transactionHash: '',
            errorMessage: ''
        });
    };

    const handleMaxClick = () => {
        setInputValue((MaxPerMINT - balance));
    };

    const handleMintClick = () => {
        const priceInWei = parseEther(price.toString());
        const amountBigNumber = BigInt(inputValue);
        const totalPriceInWei = priceInWei * amountBigNumber;
        console.log('price', priceInWei, amountBigNumber, totalPriceInWei)

        handleBuy(account, inputValue, price)
        setShowModal(true);
        setModalData({ isLoading: isLoading, isSuccess: isSuccess, transactionHash: txData?.hash ?? '', errorMessage: TxError?.cause ? TxError.message : '' });
        readData()
    };
    const closeModal = () => {
        setShowModal(false);
    };

    let buttonText = 'Connect a Wallet';
    if (isConnected && network) {
        if (network !== 280 && network !== 5611) {
            buttonText = 'Wrong Network';
        } else if (ELIGIBLE_ADDRESS.includes(account as string)) {
            if (inputValue * Number(price) >= AccountBlance) {
                buttonText = 'Insufficient Balance';
            } else if (balance >= MaxPerMINT) {
                buttonText = 'Reached Mint Cap';
            } else if (inputValue === 0) {
                buttonText = 'Enter Amount';
            } else if (inputValue > 0 && inputValue <= (MaxPerMINT - balance)) {
                buttonText = `Mint ${inputValue} Now`;
            } else if (inputValue > (MaxPerMINT - balance)) {
                buttonText = `Wrong input`;
            }
        } else if (deadlinePassed) {
            buttonText = 'Presale ended!';
        } else if (presale === 0 || presale === 1 || presale === 3) {
            if (inputValue * Number(price) >= AccountBlance) {
                buttonText = 'Insufficient Balance';
            } else if (balance >= MaxPerMINT) {
                buttonText = 'Reached Mint Cap';
            } else if (inputValue === 0) {
                buttonText = 'Enter Amount';
            } else if (inputValue > 0 && inputValue <= (MaxPerMINT - balance)) {
                buttonText = `Mint ${inputValue} Now`;
            } else if (inputValue > (MaxPerMINT - balance)) {
                buttonText = `Wrong input`;
            }
        } else {
            buttonText = "You are NOT eligible";
        }
    } else {
        buttonText = 'Connect a Wallet';
    }

    const copyAddressToClipboard = () => {
        const address = CONTRACT_ADDRESS_TESTNET[5611];
        copy(address).then(() => {
            setCopied(true);
            setTimeout(() => {
                setCopied(false);
            }, 2000); // Revert back to original state after 2 seconds
        });
    };
    const handleDeadlinePass = (hasPassed: boolean) => {
        setDeadlinePassed(hasPassed);
    };
    return (
        <>
            <header className="w-full fixed top-0 left-0 bg-black">
                <Head>
                    <title>Presale</title>
                    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
                    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
                    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
                    <link rel="manifest" href="/site.webmanifest" />
                </Head>
                <NavApp AccountBlance={AccountBlance.toString()} />
            </header>

            <div className="bg-black lg:max-w-4xl mx-auto pt-8 lg:py-20">
                <div className="flex flex-col items-center lg:flex-row lg:gap-4">
                    <div className="w-full lg:border lg:border-white lg:border-opacity-10 lg:rounded-lg shadow-lg text-gray-200 lg:order-2">
                        <div className='pt-10 px-4 w-full m-auto'>
                            <div className="text-white text-3xl font-bold uppercase leading-loose lg:pb-2">EchoNFT {presale === 0 ? 'Public Sale' : presale === 1 ? 'Private Sale' : presale === 2 ? 'White List Sale' : 'Stop'} </div>
                            <div className="text-gray-200 text-base font-bold uppercase leading-loose pb-3">End Countdown</div>
                            <CountdownTimer onDeadlinePass={handleDeadlinePass} />
                            <div className="flex items-center pb-3 pt-6 justify-start space-x-2">
                                <span className="text-gray-200 text-sm font-normal uppercase leading-loose">TOTAL {presale === 0 ? 'Public Sale' : presale === 1 ? 'Private Sale' : presale === 2 ? 'White List Sale' : 'Stop'}</span>
                                <span className="text-white text-xl font-bold capitalize leading-loose">{TotalSupply}</span>
                                <span className="text-gray-200 text-opacity-50 text-xl font-bold capitalize leading-loose">/ {presale === 0 ? '2000' : presale === 1 ? '300' : presale === 2 ? '200' : MaxSupply} </span>
                            </div>
                            <div className="flex pb-3 space-x-2 lg:space-x-0 lg:flex-col mb-4 lg:mb-0">
                                <div className="text-gray-200 text-sm font-normal uppercase leading-loose">Contract address</div>
                                <div className="flex items-center space-x-2">
                                    <Link href={network === 5611 ? `https://opbnb-testnet.bscscan.com/address/${CONTRACT_ADDRESS_TESTNET[5611]}` : `https://explorer.zksync.io/address/${CONTRACT_ADDRESS_MAINNET}`} target="_blank" className="text-blue-600 text-sm font-normal capitalize leading-loose">
                                        {CONTRACT_ADDRESS_TESTNET[5611].slice(0, 5) + '...' + CONTRACT_ADDRESS_TESTNET[5611].slice(-5)}
                                    </Link>
                                    <button onClick={copyAddressToClipboard} className="focus:outline-none">
                                        <span className="text-white text-opacity-50 text-sm font-normal capitalize leading-loose">
                                            {copied ? <span>Copied!</span> : <TbCopy style={{ width: '24px', height: '24px' }} />}
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="hidden sm:block px-4 pt-3 w-full m-auto  text-gray-200 ">
                            <div className=" pb-12   ">
                                <p className=" lg:px-0 text-white text-opacity-60 text-xs font-normal leading-loose">
                                    EchoNFTs are integral to the community-owned protocol, offering unique benefits and passive income opportunities to their holders.
                                    With a total supply of 2500, these NFTs unlock various revenue streams, such as trading fees, fair launch airdrops, and additional rewards.
                                    <Link
                                        href="https://docs.echoswap.xyz/echoswap/terminology-know/tokenomics#echonft"
                                        key="Learn more"
                                        target="_blank"
                                        className="text-blue-600 text-sm font-normal capitalize leading-normal"
                                    >
                                        Learn more
                                    </Link>
                                </p>
                                <span className="pt-2.5 text-white text-opacity-60 text-xs flex items-center justify-start space-x-2 font-normal leading-loose">
                                    Click{' '}
                                    <Link
                                        href={network === 280 ? "https://testnet.zonic.app/profile?filter={%22tab%22:0,%22chain%22:280}" :
                                            "https://zonic.app/profile?filter={%22tab%22:0,%22chain%22:324}"}
                                        target="_blank"
                                        className="text-blue-600 px-1 text-sm font-normal capitalize leading-normal"
                                    >
                                        here
                                    </Link>{' '}
                                    to view your purchased NFT.
                                </span>

                            </div>

                            <div className="flex pb-12  pt-3 items-center gap-5 lg:justify-start justify-center">
                                {bottomIcons.map((item) => (
                                    <Link href={item.href} key={item.name} target="_blank">

                                        <item.icon
                                            className=" h-7 w-7 flex-shrink-0 text-gray-400  hover:text-gray-200"
                                            aria-hidden="true"
                                        />

                                    </Link>
                                ))}

                            </div>
                        </div>
                    </div>
                    <div className="w-full lg:max-w-xs lg:border lg:border-white lg:border-opacity-10 lg:rounded-lg shadow-lg text-gray-200">
                        <div className='p-4 w-full m-auto'>
                            <Image
                                src={presale === 0 ? PublicSaleNFT : presale === 1 ? PrivateSaleNFT : presale === 2 ? WhiteListSaleNFT : PublicSaleNFT}
                                alt="NFT"
                                width={300}
                                height={300}
                                className="object-cover w-full h-auto"
                            />
                            <div className=" w-full pt-4 grid grid-cols-2 ">
                                <div className="text-left pb-4 lg:pb-0 text-gray-200 text-sm font-normal capitalize leading-loose">Price</div>
                                <div className="text-right text-white text-sm font-bold capitalize leading-loose">{price} ETH</div>
                                <div className='col-span-2 pt-5 border-t border-zinc-300 border-opacity-20 ' />
                                <div className="text-left pb-4 lg:pb-0 text-gray-200 text-sm font-normal capitalize leading-loose">Minted</div>
                                <div className="text-right text-white text-sm font-bold capitalize leading-loose">{balance ? balance : '0'}/{MaxPerMINT}</div>
                                <div className='col-span-2 pt-5 border-t border-zinc-300 border-opacity-20  ' />
                                <div className="text-left text-gray-200 text-sm font-normal capitalize leading-loose">Mint Amount</div>
                                <div className="flex pb-4 lg:pb-0 justify-between ">
                                    <input
                                        type="number"
                                        className={`w-10 ${inputValue !== 0 ? 'text-white' : 'text-gray-200 text-opacity-50'}  text-sm font-normal capitalize leading-loose bg-transparent appearance-none focus:outline-none cursor-pointer`}
                                        value={inputValue}
                                        onChange={(e) => setInputValue(parseFloat(e.target.value))}
                                        min={0}
                                        max={(MaxPerMINT - balance) >= 0 ? (MaxPerMINT - balance) : 0}
                                    />
                                    <div className="text-blue-500 cursor-pointer" onClick={handleMaxClick}>
                                        Max
                                    </div>
                                </div>
                                <div className='col-span-2 border-t border-zinc-300 border-opacity-20 ' />
                                <div className='pb-11 pt-14 lg:pb-12 lg:pt-20 col-span-2'>
                                    {buttonText === 'Connect a Wallet' ?
                                        
                                            <ConnectButtonMint />
                                        

                                        :

                                        <button
                                            className={`w-full px-2.5 py-3 ${isConnected && balance === 0 ? (balance === MaxPerMINT || inputValue === 0 || buttonText === "You are NOT eligible" || buttonText === "Reached Mint Cap" || buttonText === "Wrong Network" || buttonText === "Wrong input" || buttonText === "Insufficient Balance" ? 'bg-blue-600 bg-opacity-70' : ' bg-blue-600  ') : 'bg-gray-400 '} rounded-sm  justify-center items-center inline-flex col-span-2 `}
                                            onClick={handleMintClick}
                                            disabled={!isConnected || balance === MaxPerMINT || inputValue === 0 || buttonText === "You are NOT eligible" || buttonText === "Reached Mint Cap" || buttonText === "Wrong Network" || buttonText === "Wrong input" || buttonText === "Insufficient Balance"}
                                        >
                                            <span className={`text-black ${isConnected && balance === 0 ? ' text-white' : 'text-white '} text-white text-sm font-bold capitalize leading-normal`}>
                                                {buttonText}
                                            </span>
                                        </button>
                                    }
                                </div>

                            </div>
                        </div>
                        {showModal && (
                            <TransactionModal
                                isOpen={showModal}
                                isLoading={modalData.isLoading}
                                isSuccess={modalData.isSuccess}
                                onClose={closeModal}
                                transactionHash={modalData.transactionHash}
                                errorMessage={modalData.errorMessage}
                            />
                        )}
                    </div>
                    <div className="w-full lg:hidden">
                        <div className=" px-4  pb-4 items-center  ">
                            <p className=" mb-5 lg:px-0 text-white text-opacity-60 text-xs font-normal leading-loose">
                                EchoNFTs are integral to the community-owned protocol, offering unique benefits and passive income opportunities to their holders.
                                With a total supply of 2500, these NFTs unlock various revenue streams, such as trading fees, fair launch airdrops, and additional rewards.
                                <Link
                                    href="https://docs.echoswap.xyz/echoswap/terminology-know/tokenomics#echonft"
                                    key="Learn more"
                                    target="_blank"
                                    className="text-blue-600 text-sm font-normal capitalize leading-normal"
                                >
                                    Learn more
                                </Link>
                            </p>
                            <span className="lg:px-0 text-white text-opacity-60 text-xs flex items-center justify-start space-x-2 font-normal leading-loose">
                                Click{' '}
                                <Link
                                    href={network === 280 ? "https://testnet.zonic.app/profile?filter={%22tab%22:0,%22chain%22:280}" :
                                        "https://zonic.app/profile?filter={%22tab%22:0,%22chain%22:324}"}
                                    target="_blank"
                                    className="text-blue-600 px-1 text-sm font-normal capitalize leading-normal"
                                >
                                    here
                                </Link>{' '}
                                to view your purchased NFT.
                            </span>
                        </div>

                        <div className="flex items-center gap-5 pb-4 lg:justify-start justify-center">
                            {bottomIcons.map((item) => (
                                <Link href={item.href} key={item.name} target="_blank">

                                    <item.icon
                                        className=" h-7 w-7 flex-shrink-0 text-gray-400  hover:text-gray-200"
                                        aria-hidden="true"
                                    />

                                </Link>
                            ))}

                        </div>
                    </div>
                </div>


            </div>
        </>
    )
}
export default Presal