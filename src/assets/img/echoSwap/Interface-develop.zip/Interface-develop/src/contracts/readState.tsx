import { useContractRead, useAccount } from 'wagmi';
import { useNetworkInfo } from './network';
import EchoHoldersABI from './abi/EchoHolders.json';
import { CONTRACT_ADDRESS_TESTNET } from './addresses';

const contractAddress = CONTRACT_ADDRESS_TESTNET[5611]
export const useNFTPrice = () => {
  try {
    
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'NFT_PRICE',
    });
    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


};
export const useMAXSupply = () => {
  try {
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'MAX_SUPPLY',
    });


    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


}
export const usePresale = () => {
  try {
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'presale',
    });


    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


};
export const useMAXPerMint = () => {
  try {
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'MAX_PER_MINT',
    });


    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


};
export const usetotalSupply = () => {
  try {
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'totalSupply',
    });


    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


};
export const useMAX_RESERVE = () => {
  try {
    const { data, isError, isLoading } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'MAX_RESERVE',
    });


    return { data, isError, isLoading };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }


};
export const useBalanceOf = (account: string) => {
  try {
    const { data, isError } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'balanceOf',
      args: [account],
    });

    return { data, isError };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }

};
export const useWhiteListSaleBalance = (account: string) => {
  try {
    const { data, isError } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'whiteListSale',
      args: [account],
    });

    return { data, isError };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }

};
export const usePrivateSaleeBalance = (account: string) => {
  try {
    const { data, isError } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'privateSale',
      args: [account],
    });

    return { data, isError };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }

};
export const usePublicSaleBalance = (account: string) => {
  try {
    const { data, isError } = useContractRead({
      address: contractAddress as `0x${string}`,
      abi: EchoHoldersABI.abi,
      functionName: 'publicSale',
      args: [account],
    });

    return { data, isError };
  } catch (error) {
    console.log(error)
    return { data: null, isError: true, isLoading: false };
  }

};