import { useContractWrite } from 'wagmi';
import { ethers } from 'ethers';
import EchoHoldersABI from './abi/EchoHolders.json';
import { CONTRACT_ADDRESS_TESTNET } from './addresses';
import {WHIT_LISTE_ADDRESS} from './eligibleAddress'
const { MerkleTree } = require('merkletreejs')

const contractAddress = CONTRACT_ADDRESS_TESTNET[5611]
export const Buy = () => {
  const merkleRoot = '0x774fb6c49c5f6473c454fc7f1ced6a1b3e97d00935c0238817ece4485c910a91';

  function generateMerkleProof(addressToProof: string): string[] {
    const leaves = WHIT_LISTE_ADDRESS.map((address) => ethers.keccak256(ethers.keccak256(address)));
    const merkleTree = new MerkleTree(leaves, ethers.keccak256, { sortPairs: true });
    const leaf = ethers.keccak256(ethers.keccak256(addressToProof))
    const buf2hex = (x: Buffer): string => '0x' + x.toString('hex');
    const proof = merkleTree.getProof(leaf);
    const formattedProof = proof.map((element: any) => buf2hex(element.data));
    return formattedProof;
  }
  const { data, isLoading, isSuccess, error, write } = useContractWrite({
    address: contractAddress as `0x${string}`,
    abi: EchoHoldersABI.abi,
    functionName: 'buy',
    args: [],
  });
  
  const handleBuy = (account: string, amount: number, price: string) => {
    
      const formattedProof = generateMerkleProof(account);
      const priceInWei = ethers.parseEther(price.toString());
  
      // Create a BigNumber instance for amount
      const amountBigNumber = ethers.toBigInt(amount);
  
      // Perform the multiplication
      const totalPriceInWei = priceInWei* amountBigNumber;
      write({
        args: [amount, formattedProof],
        value: totalPriceInWei,
      });
    
  };
  
  return { data, isLoading, isSuccess, error, handleBuy };  
  
};
