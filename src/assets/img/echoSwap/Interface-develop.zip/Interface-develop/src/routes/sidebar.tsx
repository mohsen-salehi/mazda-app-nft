 import {
    TbBrandTwitterFilled,
    TbBrandDiscordFilled,
    TbFileFilled,
  } from 'react-icons/tb'
  
  
  interface IBottomIcons {
    name: string
    href: string
    icon?: any
  }
  
  const bottomIcons: IBottomIcons[] = [
    {
      name: 'Discord',
      href: 'https://discord.gg/vFs9qVdGmV',
      icon: TbBrandDiscordFilled,
    },
    {
      name: 'Twitter',
      href: 'https://twitter.com/echo_swap',
      icon: TbBrandTwitterFilled,
    },
   
    {
      name: 'Doc',
      href: 'https://docs.echoswap.xyz/echoswap/',
      icon: TbFileFilled,
    },
  ]
  
 
  export { bottomIcons }
  