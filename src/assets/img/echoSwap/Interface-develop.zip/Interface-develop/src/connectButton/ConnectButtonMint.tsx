import { ConnectButton } from '@rainbow-me/rainbowkit';
export const ConnectButtonMint = () => {
    return (
        <ConnectButton.Custom>
            {({
                account,
                chain,
                openAccountModal,
                openChainModal,
                openConnectModal,
                authenticationStatus,
                mounted,
            }) => {
                // Note: If your app doesn't use authentication, you
                // can remove all 'authenticationStatus' checks
                const ready = mounted && authenticationStatus !== 'loading';
                const connected =
                    ready &&
                    account &&
                    chain &&
                    (!authenticationStatus ||
                        authenticationStatus === 'authenticated');

                return (
                    <div
                        {...(!ready && {
                            'aria-hidden': true,
                            'style': {
                                opacity: 0,
                                pointerEvents: 'none',
                                userSelect: 'none',
                            },
                        })}
                    >
                        {(() => {
                            if (!connected) {
                                return (
                                    <button onClick={openConnectModal} className=" w-full px-2.5 py-3 bg-gray-400 hover:bg-gray-200 rounded-sm justify-center items-center inline-flex col-span-2 ">
                                        <div className=" text-black text-sm font-bold capitalize ">
                                            Connect Wallet
                                        </div>

                                       
                                    </button>
                                        

                                );
                            }
                            
                        })()}
                    </div>
                );
            }}
        </ConnectButton.Custom>
    )
}